// ============================================
// Грузовоз — CMS через Google Sheets + Toggle блоков
// ============================================

const CONFIG = {
    CMS_SHEET_ID: 'YOUR_CMS_SHEET_ID',
    ORDERS_SHEET_ID: 'YOUR_ORDERS_SHEET_ID',
    API_KEY: ''
};

let cmsData = {};

// ============================================
// CMS Loader
// ============================================

async function loadCMSData() {
    showCMSLoading();

    try {
        if (CONFIG.CMS_SHEET_ID && CONFIG.CMS_SHEET_ID !== 'YOUR_CMS_SHEET_ID') {
            const data = await fetchSheetData(CONFIG.CMS_SHEET_ID, 'CMS');
            if (data && data.length > 0) {
                cmsData = parseCMSData(data);
                applyCMSData();
                applyToggleBlocks();
            }
        }
    } catch (error) {
        console.log('CMS load error:', error);
    }

    hideCMSLoading();
}

async function fetchSheetData(sheetId, sheetName) {
    const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&sheet=${sheetName}`;
    const response = await fetch(csvUrl);
    const csvText = await response.text();
    return parseCSV(csvText);
}

function parseCSV(csvText) {
    const lines = csvText.split('\n');
    const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());
    const result = [];

    for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const values = lines[i].split(',').map(v => v.replace(/"/g, '').trim());
        const row = {};
        headers.forEach((h, idx) => {
            row[h] = values[idx] || '';
        });
        result.push(row);
    }

    return result;
}

function parseCMSData(data) {
    const cms = {};

    data.forEach(row => {
        const key = row['Ключ'] || row['key'] || row['Key'];
        const value = row['Значение'] || row['value'] || row['Value'];
        const type = row['Тип'] || row['type'] || row['Type'] || 'text';

        if (key) {
            if (type === 'toggle') {
                cms[key] = {
                    value: value === true || value === 'true' || value === 'TRUE' || value === 'да' || value === 'Да',
                    type: type
                };
            } else {
                cms[key] = { value, type };
            }
        }
    });

    return cms;
}

// ============================================
// Toggle блоков — ВКЛ/ВЫКЛ секций
// ============================================

function applyToggleBlocks() {
    // Объект соответствия: ключ CMS → ID секции на сайте
    const toggleMap = {
        'show_calculator': 'calculator',
        'show_map': 'map',
        'show_fleet': 'fleet',
        'show_gallery': 'gallery',
        'show_steps': null,  // специальная обработка ниже
        'show_features': null,
        'show_formula': null,
        'show_order_form': 'order',
        'show_materials': 'materials',
        'show_slider': 'slider',
        'show_cms_gallery': 'cms-gallery'
    };

    for (const [key, sectionId] of Object.entries(toggleMap)) {
        if (cmsData[key] !== undefined) {
            const isVisible = cmsData[key].value === true || cmsData[key].value === 'true';

            if (sectionId) {
                // Обычная секция по ID
                toggleSection(sectionId, isVisible);
            } else {
                // Специальные секции (не по ID, а по классу/структуре)
                toggleSpecialSection(key, isVisible);
            }
        }
    }
}

function toggleSection(sectionId, isVisible) {
    const section = document.getElementById(sectionId);
    if (!section) return;

    // Находим родительский .section если это внутренний элемент
    let target = section;
    if (!section.classList.contains('section')) {
        target = section.closest('.section') || section.closest('.hero') || section;
    }

    if (isVisible) {
        target.style.display = '';
        target.classList.remove('cms-hidden');
    } else {
        target.style.display = 'none';
        target.classList.add('cms-hidden');
    }
}

function toggleSpecialSection(key, isVisible) {
    let selector = '';

    switch(key) {
        case 'show_steps':
            // Блок "Как это работает" — ищем по классу how-it-works
            document.querySelectorAll('.how-it-works').forEach(el => {
                el.style.display = isVisible ? '' : 'none';
            });
            break;

        case 'show_features':
            // Блок "Почему выбирают нас" — ищем по классу why-us
            document.querySelectorAll('.why-us').forEach(el => {
                el.style.display = isVisible ? '' : 'none';
            });
            break;

        case 'show_formula':
            // Блок с формулой — ищем по заголовку
            document.querySelectorAll('.section').forEach(section => {
                const header = section.querySelector('.section-header h2');
                if (header && header.textContent.includes('Формула')) {
                    section.style.display = isVisible ? '' : 'none';
                }
            });
            break;
    }
}

// ============================================
// Применение CMS данных
// ============================================

function applyCMSData() {
    // Общие настройки
    if (cmsData.site_title) document.title = cmsData.site_title.value;
    if (cmsData.meta_description) {
        const meta = document.querySelector('meta[name="description"]');
        if (meta) meta.content = cmsData.meta_description.value;
    }

    // Цвета темы
    if (cmsData.color_primary) document.documentElement.style.setProperty('--primary', cmsData.color_primary.value);
    if (cmsData.color_primary_dark) document.documentElement.style.setProperty('--primary-dark', cmsData.color_primary_dark.value);
    if (cmsData.color_primary_light) document.documentElement.style.setProperty('--primary-light', cmsData.color_primary_light.value);
    if (cmsData.color_accent) document.documentElement.style.setProperty('--accent', cmsData.color_accent.value);

    // Телефон
    if (cmsData.phone) {
        document.querySelectorAll('.header-phone a, .cta-phone').forEach(el => {
            el.textContent = cmsData.phone.value;
            el.href = 'tel:' + cmsData.phone.value.replace(/[^\d+]/g, '');
        });
    }

    // Email
    if (cmsData.email) {
        document.querySelectorAll('a[href^="mailto:"]').forEach(el => {
            el.href = 'mailto:' + cmsData.email.value;
            el.textContent = cmsData.email.value;
        });
    }

    // Адрес
    if (cmsData.address) {
        const addressEl = document.getElementById('cms-address');
        if (addressEl) addressEl.innerHTML = '🏢 ' + cmsData.address.value;
    }

    // Режим работы
    if (cmsData.work_hours) {
        const workEl = document.getElementById('cms-work-time');
        if (workEl) workEl.textContent = '⏰ ' + cmsData.work_hours.value;

        const headerHours = document.querySelector('.header-phone span');
        if (headerHours) headerHours.textContent = cmsData.work_hours.value;
    }

    // Тексты секций
    if (cmsData.hero_title) {
        const el = document.getElementById('cms-hero-title');
        if (el) el.textContent = cmsData.hero_title.value;
    }

    if (cmsData.hero_subtitle) {
        const el = document.getElementById('cms-hero-subtitle');
        if (el) el.textContent = cmsData.hero_subtitle.value;
    }

    if (cmsData.cta_title) {
        const el = document.getElementById('cms-cta-title');
        if (el) el.textContent = cmsData.cta_title.value;
    }

    if (cmsData.cta_text) {
        const el = document.getElementById('cms-cta-desc');
        if (el) el.textContent = cmsData.cta_text.value;
    }

    // Цены материалов
    if (cmsData.price_pesok) updateMaterialPrice('pesok', cmsData.price_pesok.value);
    if (cmsData.price_sheben) updateMaterialPrice('sheben', cmsData.price_sheben.value);
    if (cmsData.price_grunt) updateMaterialPrice('grunt', cmsData.price_grunt.value);
    if (cmsData.price_torf) updateMaterialPrice('torf', cmsData.price_torf.value);
    if (cmsData.price_pesok_seyaniy) updateMaterialPrice('pesok-seyaniy', cmsData.price_pesok_seyaniy.value);
    if (cmsData.price_sheben_izvestnyak) updateMaterialPrice('sheben-izvestnyak', cmsData.price_sheben_izvestnyak.value);
    if (cmsData.price_beton) updateMaterialPrice('beton', cmsData.price_beton.value);

    // Обновляем формулу на странице
    if (cmsData.delivery_price) {
        const rateEl = document.getElementById('cms-delivery-rate');
        if (rateEl) rateEl.textContent = cmsData.delivery_price.value;
    }
    if (cmsData.delivery_step) {
        const stepEl = document.getElementById('cms-delivery-step');
        if (stepEl) stepEl.textContent = cmsData.delivery_step.value;

        const textEl = document.getElementById('cms-delivery-text');
        if (textEl) {
            const price = cmsData.delivery_price ? cmsData.delivery_price.value : '1000';
            textEl.textContent = '+' + price + ' ₽ за каждые ' + cmsData.delivery_step.value + ' км от карьера';
        }
    }

    // WhatsApp
    if (cmsData.whatsapp_number) {
        const waLink = document.getElementById('cms-whatsapp-link');
        if (waLink) waLink.href = 'https://wa.me/' + cmsData.whatsapp_number.value;
    }

    // Обновляем калькулятор
    updateCalculatorOptions();

    // Обновляем статус панели
    updateCMSPanelStatus();
}

function updateMaterialPrice(materialKey, price) {
    const option = document.querySelector(`#material option[value="${materialKey}"]`);
    if (option) option.setAttribute('data-base', price);

    const card = document.querySelector(`.material-card[data-material="${materialKey}"] .material-price`);
    if (card) card.textContent = 'от ' + Number(price).toLocaleString('ru-RU') + ' ₽/машина';
}

function updateCalculatorOptions() {
    const resultBlock = document.getElementById('result');
    if (resultBlock.classList.contains('active')) calculate();
}

function updateCMSPanelStatus() {
    const themeStatus = document.getElementById('cms-theme-status');
    const priceStatus = document.getElementById('cms-price-status');
    const phoneStatus = document.getElementById('cms-phone-status');

    if (themeStatus) themeStatus.textContent = cmsData.color_primary ? '✅ Загружено' : '❌ Нет данных';
    if (priceStatus) priceStatus.textContent = cmsData.price_pesok ? '✅ Загружено' : '❌ Нет данных';
    if (phoneStatus) phoneStatus.textContent = cmsData.phone ? cmsData.phone.value : '❌ Нет данных';
}

// ============================================
// Calculator
// ============================================

const distanceInput = document.getElementById('distance');
const distanceRange = document.getElementById('distance-range');
const rangeValue = document.getElementById('range-value');

if (distanceInput && distanceRange) {
    distanceInput.addEventListener('input', function() {
        distanceRange.value = this.value;
        rangeValue.textContent = this.value + ' км';
    });

    distanceRange.addEventListener('input', function() {
        distanceInput.value = this.value;
        rangeValue.textContent = this.value + ' км';
    });
}

function selectMaterial(value, basePrice) {
    const select = document.getElementById('material');
    if (select) {
        select.value = value;
        updateMaterialHighlight();
        document.getElementById('calculator').scrollIntoView({ behavior: 'smooth' });
    }
}

function updateMaterialHighlight() {
    const select = document.getElementById('material');
    if (!select) return;
    const value = select.value;
    document.querySelectorAll('.material-card').forEach(card => {
        card.classList.remove('selected');
        if (card.dataset.material === value) card.classList.add('selected');
    });
}

function calculate() {
    const materialSelect = document.getElementById('material');
    if (!materialSelect) return;

    const selectedOption = materialSelect.options[materialSelect.selectedIndex];
    const basePrice = parseInt(selectedOption.getAttribute('data-base')) || 0;
    const distance = parseInt(document.getElementById('distance').value) || 0;
    const quantity = parseInt(document.getElementById('quantity').value) || 1;

    if (!basePrice) { alert('Пожалуйста, выберите материал'); return; }
    if (distance < 1) { alert('Укажите корректное расстояние'); return; }

    let deliveryRate = 1000;
    let deliveryStep = 10;

    if (cmsData.delivery_price) deliveryRate = parseInt(cmsData.delivery_price.value) || 1000;
    if (cmsData.delivery_step) deliveryStep = parseInt(cmsData.delivery_step.value) || 10;

    const deliveryCost = Math.ceil(distance / deliveryStep) * deliveryRate;
    const perTruck = basePrice + deliveryCost;
    const total = perTruck * quantity;

    document.getElementById('total-price').textContent = total.toLocaleString('ru-RU') + ' ₽';
    document.getElementById('result-detail').innerHTML = 
        '<strong>Материал:</strong> ' + selectedOption.text + '<br>' +
        '<strong>Базовая стоимость:</strong> ' + basePrice.toLocaleString('ru-RU') + ' ₽/машина<br>' +
        '<strong>Расстояние:</strong> ' + distance + ' км (+' + deliveryCost.toLocaleString('ru-RU') + ' ₽ за доставку)<br>' +
        '<strong>Стоимость за 1 машину:</strong> ' + perTruck.toLocaleString('ru-RU') + ' ₽<br>' +
        '<strong>Количество машин:</strong> ' + quantity + '<br>' +
        '<strong style="color: var(--primary);">Итого к оплате: ' + total.toLocaleString('ru-RU') + ' ₽</strong>';
    document.getElementById('result').classList.add('active');
}

// ============================================
// UI Functions
// ============================================

function showCMSLoading() {
    const loader = document.getElementById('cms-loader');
    if (loader) loader.classList.remove('hidden');
}

function hideCMSLoading() {
    const loader = document.getElementById('cms-loader');
    if (loader) loader.classList.add('hidden');
}

function toggleCMSPanel() {
    const panel = document.getElementById('cms-panel');
    panel.classList.toggle('active');
}

function toggleMobileMenu() {
    const nav = document.querySelector('.nav');
    if (nav.style.display === 'flex') {
        nav.style.display = 'none';
    } else {
        nav.style.display = 'flex';
        nav.style.position = 'absolute';
        nav.style.top = '100%';
        nav.style.left = '0';
        nav.style.right = '0';
        nav.style.background = 'white';
        nav.style.flexDirection = 'column';
        nav.style.padding = '1rem';
        nav.style.boxShadow = 'var(--shadow-lg)';
        nav.style.gap = '1rem';
    }
}

// ============================================
// Scroll Animations
// ============================================

const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('visible');
    });
}, observerOptions);

document.querySelectorAll('.animate-on-scroll').forEach(el => {
    observer.observe(el);
});

window.addEventListener('scroll', () => {
    const header = document.getElementById('header');
    if (window.scrollY > 50) header.classList.add('scrolled');
    else header.classList.remove('scrolled');
});

// ============================================
// Image Modal
// ============================================

function openImageModal(element) {
    const img = element.querySelector('img');
    document.getElementById('modalImage').src = img.src;
    document.getElementById('modalImage').alt = img.alt;
    document.getElementById('imageModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeImageModal() {
    document.getElementById('imageModal').classList.remove('active');
    document.body.style.overflow = '';
}

function openOrderModal() {
    document.getElementById('order').scrollIntoView({ behavior: 'smooth' });
}

// ============================================
// Yandex Maps
// ============================================

function initMap() {
    if (typeof ymaps !== 'undefined') {
        ymaps.ready(function() {
            const coords = cmsData.map_coords ? 
                cmsData.map_coords.value.split(',').map(Number) : 
                [55.7558, 37.6173];

            const map = new ymaps.Map('yandex-map', {
                center: coords,
                zoom: 10,
                controls: ['zoomControl', 'typeSelector']
            });

            const placemark = new ymaps.Placemark(coords, {
                balloonContent: '<strong>Грузовоз</strong><br>База отгрузки',
                hintContent: 'База Грузовоз'
            }, {
                preset: 'islands#greenDotIconWithCaption'
            });

            map.geoObjects.add(placemark);

            const radius = cmsData.delivery_radius ? 
                parseInt(cmsData.delivery_radius.value) * 1000 : 150000;

            const circle = new ymaps.Circle([coords, radius], {
                balloonContent: 'Зона доставки'
            }, {
                fillColor: '#1a5f2a20',
                strokeColor: '#1a5f2a',
                strokeWidth: 2
            });

            map.geoObjects.add(circle);
        });
    }
}

window.addEventListener('load', initMap);

// ============================================
// Google Sheets Integration (Orders)
// ============================================

const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec';

function submitOrder(event) {
    event.preventDefault();

    const btn = document.getElementById('submitBtn');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="loading"></span> Отправка...';
    btn.disabled = true;

    const data = {
        action: 'order',
        name: document.getElementById('order-name').value,
        phone: document.getElementById('order-phone').value,
        material: document.getElementById('order-material').value,
        quantity: document.getElementById('order-quantity').value,
        address: document.getElementById('order-address').value,
        comment: document.getElementById('order-comment').value,
        timestamp: new Date().toLocaleString('ru-RU'),
        source: 'Website'
    };

    fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(() => showSuccess())
    .catch(() => showSuccess())
    .finally(() => {
        btn.innerHTML = originalText;
        btn.disabled = false;
    });
}

function showSuccess() {
    document.getElementById('orderFormContainer').style.display = 'none';
    document.getElementById('formSuccess').classList.add('active');
}

function resetForm() {
    document.getElementById('orderForm').reset();
    document.getElementById('orderFormContainer').style.display = 'block';
    document.getElementById('formSuccess').classList.remove('active');
}

// ============================================
// Phone Mask
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    const phoneInput = document.getElementById('order-phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 0) {
                if (value[0] === '7' || value[0] === '8') value = value.substring(1);
                let formatted = '+7';
                if (value.length > 0) formatted += ' (' + value.substring(0, 3);
                if (value.length >= 3) formatted += ') ' + value.substring(3, 6);
                if (value.length >= 6) formatted += '-' + value.substring(6, 8);
                if (value.length >= 8) formatted += '-' + value.substring(8, 10);
                e.target.value = formatted;
            }
        });
    }

    loadCMSData();
});

// ============================================
// Smooth Scroll
// ============================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
});
