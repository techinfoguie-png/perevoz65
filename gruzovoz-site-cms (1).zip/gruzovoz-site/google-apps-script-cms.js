// ============================================
// Google Apps Script — CMS + Заявки + Toggle блоков
// ============================================

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var action = data.action || 'order';

    if (action === 'order') {
      return saveOrder(data);
    } else if (action === 'get_cms') {
      return getCMSData();
    }

  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      'result': 'error',
      'message': error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  try {
    var action = e.parameter.action || 'cms';

    if (action === 'cms') {
      return getCMSData();
    } else {
      return ContentService.createTextOutput(JSON.stringify({
        'result': 'success',
        'message': 'API работает. Используйте ?action=cms'
      })).setMimeType(ContentService.MimeType.JSON);
    }

  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      'result': 'error',
      'message': error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

// ============================================
// Сохранение заявки
// ============================================
function saveOrder(data) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Заявки');

  if (!sheet) {
    sheet = ss.insertSheet('Заявки');
    sheet.appendRow(['Дата', 'Имя', 'Телефон', 'Материал', 'Количество', 'Адрес', 'Комментарий', 'Источник']);
    sheet.getRange(1, 1, 1, 8).setFontWeight('bold').setBackground('#1a5f2a').setFontColor('white');
  }

  sheet.appendRow([
    data.timestamp || new Date().toLocaleString('ru-RU'),
    data.name || '',
    data.phone || '',
    data.material || '',
    data.quantity || '',
    data.address || '',
    data.comment || '',
    data.source || 'Website'
  ]);

  return ContentService.createTextOutput(JSON.stringify({
    'result': 'success',
    'message': 'Заявка сохранена'
  })).setMimeType(ContentService.MimeType.JSON);
}

// ============================================
// Получение CMS данных
// ============================================
function getCMSData() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('CMS');

  if (!sheet) {
    createDefaultCMS(ss);
    sheet = ss.getSheetByName('CMS');
  }

  var data = sheet.getDataRange().getValues();
  var headers = data[0];
  var result = {};

  for (var i = 1; i < data.length; i++) {
    var key = data[i][0];
    var value = data[i][1];
    var type = data[i][2] || 'text';

    if (key) {
      // Для toggle-типа преобразуем в boolean
      if (type === 'toggle') {
        result[key] = {
          'value': value === true || value === 'true' || value === 'TRUE' || value === 'да' || value === 'Да',
          'type': type
        };
      } else {
        result[key] = {
          'value': value,
          'type': type
        };
      }
    }
  }

  return ContentService.createTextOutput(JSON.stringify({
    'result': 'success',
    'data': result
  })).setMimeType(ContentService.MimeType.JSON);
}

// ============================================
// Создание дефолтной CMS таблицы
// ============================================
function createDefaultCMS(ss) {
  var sheet = ss.insertSheet('CMS');

  var defaultData = [
    ['Ключ', 'Значение', 'Тип', 'Описание'],

    // === ОБЩИЕ НАСТРОЙКИ ===
    ['site_title', 'Грузовоз — Доставка сыпучих материалов', 'text', 'Заголовок вкладки браузера'],
    ['meta_description', 'Доставка песка, щебня, грунта самосвалами 6 м³ по Москве и области', 'text', 'SEO описание'],
    ['phone', '+7 (999) 123-45-67', 'text', 'Телефон компании'],
    ['email', 'info@gruzovoz.ru', 'text', 'Email компании'],
    ['address', 'Москва, ул. Строителей, 15', 'text', 'Адрес офиса/базы'],
    ['work_hours', 'Работаем 24/7', 'text', 'Режим работы'],
    ['whatsapp_number', '79991234567', 'text', 'Номер для WhatsApp (без +)'],

    // === СЛАЙДЕР ===
    ['show_slider', 'true', 'toggle', 'Показывать слайдер работ'],
    ['slider_title', 'Выполненные работы', 'text', 'Заголовок слайдера'],
    ['slider_desc', 'Примеры наших доставок и объектов', 'text', 'Подпись слайдера'],

    // === CMS ГАЛЕРЕЯ (JSON формат) ===
    ['show_cms_gallery', 'true', 'toggle', 'Показывать галерею из CMS'],
    ['cms_gallery_title', 'Наши объекты', 'text', 'Заголовок галереи'],
    ['cms_gallery_desc', 'Фото с реальных объектов', 'text', 'Подпись галереи'],
    ['gallery_images', '[{"url":"https://example.com/photo1.jpg","title":"Объект 1","description":"Описание"},{"url":"https://example.com/photo2.jpg","title":"Объект 2","description":"Описание"}]', 'json', 'JSON массив картинок (url, title, description)'],

    // === ЦВЕТА ТЕМЫ ===
    ['color_primary', '#1a5f2a', 'color', 'Основной цвет (зелёный)'],
    ['color_primary_dark', '#124a1f', 'color', 'Тёмный оттенок'],
    ['color_primary_light', '#2d8a42', 'color', 'Светлый оттенок'],
    ['color_accent', '#f4a261', 'color', 'Акцентный цвет (оранжевый)'],

    // === ТЕКСТЫ ===
    ['hero_title', 'Доставка сыпучих материалов самосвалами 6 м³', 'text', 'Главный заголовок'],
    ['hero_subtitle', 'Перевозим песок, щебень, грунт и другие сыпучие материалы по Москве и области. 4 самосвала в собственном автопарке.', 'text', 'Подзаголовок'],
    ['cta_title', 'Готовы сделать заказ?', 'text', 'Заголовок CTA блока'],
    ['cta_text', 'Позвоните прямо сейчас — рассчитаем стоимость и подадим машину в течение 2 часов', 'text', 'Текст CTA блока'],

    // === ЦЕНЫ МАТЕРИАЛОВ ===
    ['price_pesok', '4500', 'number', 'Цена песка за 6м³'],
    ['price_sheben', '5200', 'number', 'Цена щебня за 6м³'],
    ['price_grunt', '3800', 'number', 'Цена грунта за 6м³'],
    ['price_pesok_seyaniy', '4800', 'number', 'Цена сеяного песка'],
    ['price_sheben_izvestnyak', '4600', 'number', 'Цена известнякового щебня'],
    ['price_torf', '5500', 'number', 'Цена торфа за 6м³'],
    ['price_beton', '6500', 'number', 'Цена бетона за 6м³'],

    // === НАСТРОЙКИ ДОСТАВКИ ===
    ['delivery_price', '1000', 'number', 'Стоимость доставки за шаг'],
    ['delivery_step', '10', 'number', 'Шаг доставки в км'],
    ['delivery_radius', '150', 'number', 'Радиус доставки в км'],
    ['map_coords', '55.7558, 37.6173', 'text', 'Координаты базы (широта, долгота)'],

    // === TOGGLE БЛОКИ (вкл/выкл секции) ===
    // Значение: true/да/Да/TRUE — включено, false/нет/Нет/FALSE — выключено
    ['show_calculator', 'true', 'toggle', 'Показывать калькулятор'],
    ['show_map', 'true', 'toggle', 'Показывать карту'],
    ['show_fleet', 'true', 'toggle', 'Показывать автопарк'],
    ['show_gallery', 'true', 'toggle', 'Показывать галерею'],
    ['show_steps', 'true', 'toggle', 'Показывать блок "Как это работает"'],
    ['show_features', 'true', 'toggle', 'Показывать блок "Почему выбирают нас"'],
    ['show_formula', 'true', 'toggle', 'Показывать блок с формулой расчёта'],
    ['show_order_form', 'true', 'toggle', 'Показывать форму заказа'],
    ['show_materials', 'true', 'toggle', 'Показывать блок материалов']
  ];

  sheet.getRange(1, 1, defaultData.length, 4).setValues(defaultData);
  sheet.getRange(1, 1, 1, 4).setFontWeight('bold').setBackground('#1a5f2a').setFontColor('white');
  sheet.autoResizeColumns(1, 4);
}
